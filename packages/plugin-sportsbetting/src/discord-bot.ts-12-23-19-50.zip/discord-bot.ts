import {
    ButtonInteraction,
    ChannelType,
    Client,
    EmbedBuilder,
    GatewayIntentBits,
    TextChannel,
} from 'discord.js';

import { BrowserService } from './services/browser';
import { scrapeMatchPreview } from './standalone-test';
import {
    MatchPreview,
    PreviewMatch,
    PreviewSection,
} from './types';

export class DiscordBot {
    public client: Client;
    private previewCache: Map<string, MatchPreview> = new Map();
    private applicationId: string;
    private sections: PreviewSection[] = [];

    constructor(token: string) {
        this.applicationId = process.env.DISCORD_APPLICATION_ID || "";
        this.client = new Client({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent,
            ],
        });

        this.setupEventHandlers();
        this.client.login(token);
    }

    private setupEventHandlers() {
        this.client.on("ready", () => {
            console.log(`Bot logged in as ${this.client.user?.tag}`);
        });

        this.client.on("interactionCreate", async (interaction) => {
            if (!interaction.isButton()) return;

            const [action] = interaction.customId.split("_");
            if (action === "load") {
                await this.handleButtonClick(interaction);
            }
        });
    }

    private async handlePreviewButton(
        interaction: ButtonInteraction,
        sectionName: string,
        matchIndex: number
    ) {
        await interaction.deferReply({ ephemeral: true });
        const [_, section, idx, previewType] = interaction.customId.split("_");

        try {
            const match = this.sections.find((s) => s.section === section)
                ?.matches[matchIndex];

            if (!match) {
                await interaction.editReply("Match not found");
                return;
            }

            // Create browser instance outside the preview check
            const browserService = await BrowserService.getInstance();
            const page = await browserService.newPage();

            try {
                const preview = await scrapeMatchPreview(page, match.url);
                if (preview) {
                    this.previewCache.set(`${section}_${idx}`, preview);
                    const embed = this.createPreviewEmbed(
                        match,
                        preview,
                        previewType
                    );
                    await interaction.editReply({ embeds: [embed] });
                } else {
                    await interaction.editReply("Could not load match preview");
                }
            } finally {
                await browserService.close();
            }
        } catch (error) {
            console.error("Error fetching preview:", error);
            await interaction.editReply("Error loading match preview");
        }
    }

    private createPreviewEmbed(
        match: PreviewMatch,
        preview: MatchPreview,
        previewType: string
    ): EmbedBuilder {
        const embed = new EmbedBuilder()
            .setColor(0x3498db)
            .setTitle(`${match.time} - ${match.match}`)
            .setURL(match.url)
            .addFields([
                {
                    name: "📝 Match Summary",
                    value:
                        preview.matchSummary?.substring(0, 1024) ||
                        "No summary available",
                    inline: false,
                },
                {
                    name: `👥 ${preview.homeTeam} Team News`,
                    value:
                        preview.teamNews?.home?.join("\n").substring(0, 1024) ||
                        "No team news available",
                    inline: false,
                },
                {
                    name: `👥 ${preview.awayTeam} Team News`,
                    value:
                        preview.teamNews?.away?.join("\n").substring(0, 1024) ||
                        "No team news available",
                    inline: false,
                },
                {
                    name: `📊 Form Guide`,
                    value: [
                        `${preview.homeTeam}: ${preview.formGuide?.home?.join(", ") || "No data"}`,
                        `${preview.awayTeam}: ${preview.formGuide?.away?.join(", ") || "No data"}`,
                    ].join("\n"),
                    inline: false,
                },
                {
                    name: "🎯 Prediction",
                    value: preview.prediction || "No prediction available",
                    inline: false,
                },
                {
                    name: "🔗 Quick Links",
                    value: `[View Full Preview on Sports Mole](${match.url})`,
                    inline: false,
                },
            ])
            .setTimestamp();

        return embed;
    }

    public async sendMatchOverview(
        sections: PreviewSection[],
        previews: Map<string, MatchPreview>
    ) {
        this.sections = sections;
        const channelId = process.env.DISCORD_CHANNEL_ID;
        if (!channelId) {
            console.error("❌ DISCORD_CHANNEL_ID not set in .env file");
            return;
        }

        const channel = this.client.channels.cache.get(
            channelId
        ) as TextChannel;
        if (!channel || channel.type !== ChannelType.GuildText) {
            console.error("❌ Could not find Discord channel:", channelId);
            return;
        }

        try {
            // Create the main overview message with all matches
            const today = new Date();
            let description = `${today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}\n\n`;

            // Add each section and its matches directly to the description
            for (const section of sections) {
                if (section.matches.length === 0) continue; // Skip empty sections
                
                description += `**${section.section}**\n`;
                for (const match of section.matches) {
                    description += `• ${match.time} EST - ${match.match}\n`;
                }
                description += '\n';
            }

            const overviewEmbed = new EmbedBuilder()
                .setColor(0x3498db)
                .setTitle("Today's Available Match Previews")
                .setDescription(description.trim());

            // Send the main overview message
            const overviewMessage = await channel.send({
                embeds: [overviewEmbed]
            });

            const browserService = await BrowserService.getInstance();

            // Process each section
            for (const section of sections) {
                if (section.matches.length === 0) continue; // Skip empty sections
                
                // Create a thread for this section
                const threadName = `📋 ${section.section} Previews`;
                const sectionThread = await overviewMessage.startThread({
                    name: threadName,
                    autoArchiveDuration: 1440,
                });

                // Process matches for this section in parallel
                const matchPromises = section.matches.map(async (match) => {
                    const page = await browserService.newPage();
                    try {
                        console.log(`Scraping data for: ${match.url}`);
                        const preview = await scrapeMatchPreview(page, match.url);

                        if (preview) {
                            // Format the preview message in bullet point format
                            const previewText = 
                                `**${match.match}**\n\n` +
                                "**1. Match Context**\n" +
                                `• Teams: ${preview.homeTeam} vs ${preview.awayTeam}\n` +
                                `• Venue: ${preview.venue || 'Not specified'}\n` +
                                `• Competition: ${preview.competition || 'Not specified'}\n` +
                                `• Key Context: ${preview.matchSummary?.substring(0, 500) || 'Not available'}${preview.matchSummary?.length > 500 ? '...' : ''}\n\n` +
                                "**2. Key Information**\n" +
                                `• Injuries/returns: ${preview.keyAbsences || 'No key information available'}\n` +
                                `• Lineup changes: ${preview.lineups?.home?.length ? preview.lineups.home.join(', ') : 'No lineup information available'}\n` +
                                `• Tactical implications: ${preview.overview || 'No tactical information available'}\n\n` +
                                "**3. Team News**\n" +
                                `**${preview.homeTeam}**:\n` +
                                (preview.teamNews?.home?.map(news => `• ${news}`).join('\n') || "• No team news available") + "\n\n" +
                                `**${preview.awayTeam}**:\n` +
                                (preview.teamNews?.away?.map(news => `• ${news}`).join('\n') || "• No team news available") + "\n\n" +
                                "**4. Prediction**\n" +
                                `• Scoreline prediction: ${preview.prediction || 'Not available'}\n` +
                                `• Reasoning: ${preview.statistics || 'Not available'}\n` +
                                `• Key factors: ${preview.scoreAnalysis || 'Not available'}`;

                            // Split message if it's too long (Discord has a 2000 character limit)
                            const maxLength = 1900; // Leave some room for formatting
                            if (previewText.length > maxLength) {
                                const parts = previewText.match(new RegExp(`.{1,${maxLength}}`, 'g')) || [];
                                for (let i = 0; i < parts.length; i++) {
                                    await sectionThread.send(parts[i] + (i < parts.length - 1 ? '\n[continued...]' : ''));
                                }
                            } else {
                                await sectionThread.send(previewText);
                            }
                        }
                    } catch (error) {
                        console.error(`Error processing match ${match.match}:`, error);
                        await sectionThread.send(`Error loading preview for ${match.match}`);
                    } finally {
                        await page.close();
                    }
                });

                // Wait for all matches in this section to be processed
                await Promise.allSettled(matchPromises);
            }

            await browserService.close();
        } catch (error) {
            console.error("Error in sendMatchOverview:", error);
        }
    }

    private async handleButtonClick(interaction: ButtonInteraction) {
        await interaction.deferReply({ ephemeral: false });

        const [action, dataType, ...urlParts] = interaction.customId.split("_");
        const url = urlParts.join("_");

        try {
            const browserService = await BrowserService.getInstance();
            const page = await browserService.newPage();

            try {
                const preview = await scrapeMatchPreview(page, url);
                if (!preview) {
                    await interaction.editReply("Could not load match data");
                    return;
                }

                // Initialize embed with common properties
                const embed = new EmbedBuilder().setColor(0x3498db).setURL(url);

                // Add specific content based on button type
                switch (dataType) {
                    case "summary":
                        embed
                            .setTitle("📝 Match Summary")
                            .setDescription(
                                preview.matchSummary || "No summary available"
                            );
                        break;

                    case "team_news":
                        embed.setTitle("👥 Team News").addFields([
                            {
                                name: preview.homeTeam,
                                value:
                                    preview.teamNews?.home?.join("\n") ||
                                    "No team news available",
                                inline: false,
                            },
                            {
                                name: preview.awayTeam,
                                value:
                                    preview.teamNews?.away?.join("\n") ||
                                    "No team news available",
                                inline: false,
                            },
                        ]);
                        break;

                    case "prediction":
                        embed
                            .setTitle("🎯 Sports Mole Prediction")
                            .setDescription(
                                preview.prediction || "No prediction available"
                            );
                        break;

                    case "form":
                        embed.setTitle("📊 Form Guide").addFields([
                            {
                                name: preview.homeTeam,
                                value:
                                    preview.formGuide?.home?.join(", ") ||
                                    "No data",
                                inline: true,
                            },
                            {
                                name: preview.awayTeam,
                                value:
                                    preview.formGuide?.away?.join(", ") ||
                                    "No data",
                                inline: true,
                            },
                        ]);
                        break;

                    default:
                        await interaction.editReply("Invalid button type");
                        return;
                }

                await interaction.editReply({ embeds: [embed] });
            } finally {
                await browserService.close();
            }
        } catch (error) {
            console.error("Error handling button click:", error);
            await interaction.editReply("Error loading data");
        }
    }

    private async getDefaultChannel(): Promise<TextChannel | null> {
        const channel = this.client.channels.cache.find(
            (channel) => channel.type === ChannelType.GuildText
        );
        return channel as TextChannel;
    }

    public async getChannel(channelId: string): Promise<TextChannel | null> {
        await this.waitForReady();
        return this.client.channels.cache.get(channelId) as TextChannel;
    }

    private async waitForReady(): Promise<void> {
        if (this.client.isReady()) return;

        return new Promise((resolve) => {
            this.client.once("ready", () => resolve());
        });
    }
}
