import { Action } from '@ai16z/eliza';

export const getBetHistoryAction: Action = {
    name: "GET_BET_HISTORY",
    description: "Get betting history for a user",
    handler: async (runtime, memory, state, options, callback) => {
        // Implementation coming soon
        return [];
    }
};
