export const CHAMPIONSHIP_TEAMS = [
    'norwich', 'burnley', 'sheffield united', 'plymouth',
    'stoke', 'cardiff', 'watford', 'west brom',
    // ... rest of teams
];

export const PREMIER_LEAGUE_TEAMS = [
    'arsenal', 'aston villa', 'chelsea', 'everton',
    'liverpool', 'manchester city', 'manchester united',
    // ... rest of teams
];

// Add other leagues as needed